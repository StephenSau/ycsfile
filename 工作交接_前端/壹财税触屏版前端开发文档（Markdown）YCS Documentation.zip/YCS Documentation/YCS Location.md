# YCS Location #

通过引入 **window.YCS.BMAP** 获得

## 1. 常用变量及说明 ##

- **geoCoord**: 用户坐标经纬度
- **geoAddress**（*String*）: 用户定位所在的详细省-市-街道地址。
- **geoLocation**:  包含具体到街道名称、周边服务区域在内的用户定位详细信息
- **geoPosition**: 经纬度详情，包括用户坐标经纬度，所在省和所在市的简单信息
- **ipCityInfo**: 根据当前IP地址获取到的用户城市信息，包括城市名、百度cityCode、城市中心点经纬度信息
- **ipCityCode**（*Number*）:  根据当前IP地址获取到的用户城市代码（百度cityCode）
- **ipCity**: 当前IP地址所在城市在YCS城市列表中对应的信息
- **customAddress**（*String*）: 用以记录用户自行输入/校正的地址信息
- **customCoord**: 根据上述用户自行输入的地址进行重新校正后的经纬度坐标
- **selectedCity**: 城市列表中当前选中的城市信息，包括省名、市名、省行政编号、市行政编号、百度cityCode
- **selectedCityCode**（*Number*）: 用户在城市列表中选中的城市代码（百度CityCode）

## 2. 信息的更新/获取 ##

上述变量均储存在浏览器localStorage下，能一直保留到浏览器或用户强制清除缓存为止。能够达到长期保存+跨页调用的效果。要获取变量信息，你可以调用下文中的 **checkExisting** 方法【推荐】。或另行使用 `YCS.UTIL.Data` 类（另文说明）。

## 3. 定位信息的优先度 ##

位置信息大致分为两类：

1. 真实定位：根据GPS / IP地址获取的定位，属用户真实定位，表现为以 geo | ip 开头的变量
2. 自定义定位：用户自行选择或输入的信息，可以和真实定位完全不同，变量通常以 custom | selected 开头

**当前产品业务逻辑要求：==自定义定位 > 真实定位==**

以城市列表控件`<city-list>`为例，假设用户自定义的 selectedCity 为北京，而真实定位的ipCity是广州，列表须采用**北京**为“当前选择”值，而广州则为“GPS定位”值。

当且仅当 selectedCity 为空时，才退一步采用ipCity（**广州**）为“当前选择”值。

## 4. 常用方法 ##

大部分常见用例已加入公用控件，并已经在demo页中展示。本文仅列出部分有可能在需要非公用控件中调用的方法。

### init 初始化 ###

> init()

初始化，通常在 attached 或 $nextTick 时调用

### checkExisting 检查现有信息 ###

> checkExisting( name, needCheckExpiry )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**name** | *String* |  | 【必传】第1点中的任意常用变量名称
**needCheckExpiry** | *Boolean* | false | 是否需要检验变量是否过期（默认为1小时）

**结果返回：**
- 若信息存在（且未过期），返回已有信息
- 若信息不存在或已过期，返回false

### getUserPos 获取用户经纬度信息 ###

> getUserPos( needDecodedAddress, callback, skipIpCityCode, forceUpdate )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**needDecodedAddress** | *Boolean* | false | 是否需要将坐标转译成具体地址
**callback** | *Function* |  | 回调函数，本方法中获得的坐标信息会一并返回
**skipIpCityCode** | *Boolean* | false | 是否跳过cityCode编译，默认为false（会自动执行编译）
**forceUpdate** | *Boolean* | false | 是否强制重新刷新。如果传值为true，则会忽略已储存的位置信息，重新向用户索取最新定位并更新到localStorage中

**结果返回：**
- 返回geoPosition信息

### coordToAddr 将坐标转译为地址 ###

> coordToAddr( coord, saveAs, callback )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**coord** | *Object* |  | 【必传】目标坐标，格式为`{lng: xxx.xxxx, lat: xx.xxxx }`
**saveAs** | *String* |  | 需要保存到localStorage时请传值。`custom`: 存为用户自定义地址（customAddress）；`geo`: 存为真实定位地址（geoAddress）
**callback** | *Function* |  | 回调函数，本方法中获得的地址信息会一并返回

**结果返回：**
- 返回转译后的文本地址信息

### addrToCoord 将地址转换为经纬度坐标 ###

> addrToCoord( address, callback, saveAs )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**address** | *String* |  | 【必传】目标地址
**callback** | *Function* |  | 回调函数，本方法中获得的坐标信息会一并返回
**saveAs** | *String* |  | 需要保存到localStorage时请传值。`custom`:存为用户自定义坐标（customCoord）；`geo`: 存为真实定位坐标（geoCoord）

**结果返回：**
- 返回转译后的坐标信息，格式为`{lng: xxx.xxxx, lat: xx.xxxx }`

### saveSelectedCity 储存用户当前选择的城市 ###

> saveSelectedCity( cityCode, callback, saveAs )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**cityCode** | *Number* |  | 【必传】该城市的百度cityCode
**callback** | *Function* |  | 回调函数，本方法中获得的城市信息会一并返回
**saveAs** | *String* |  | 需要保存为真实城市时请传值`ip`，信息将会被存为真实定位城市（ipCity）；不传值则会存为自定义城市（selectedCity）

**结果返回：**
- 返回selectedCity信息


### getUserCityCode 获取用户所在城市的百度cityCode ### 

> getUserCityCode( callback )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**callback** | *Function* |  | 回调函数，本方法中获得的城市信息会一并返回

**结果返回：**
- 返回ipCity信息


---


## 附录：常用变量示例 ##


名称 | 类型 | 说明 | 示例
---|---|---|---
**geoCoord** | *Object* | 用户坐标经纬度 | {"lng":113.30764968,"lat":23.1200491}
**geoAddress** | *String* | 用户定位所在的详细省-市-街道地址 | "广东省广州市越秀区美华北路"
**geoLocation** | *Object* | 包含具体到街道名称、周边服务区域在内的用户定位详细信息 | {"point":{"lng":113.30765,"lat":23.120049},"address":"广东省广州市越秀区美华北路","addressComponents":{"streetNumber":"","street":"美华北路","district":"越秀区","city":"广州市","province":"广东省"},"surroundingPois":[{"title":"东山湖公园","uid":"34e48508154527e2d8d8913d","point":{"lng":113.298594,"lat":23.122217},"city":"广州市","Ui":"旅游景点","type":0,"address":"东湖北路123号","postcode":null,"phoneNumber":null,"eu":["旅游景点"]}],"business":"岭南,大东,二沙岛"}
**geoPosition** | *Object* | 经纬度详情，包括用户坐标经纬度，所在省和所在市的简单信息 | {"accuracy":null,"altitude":null,"altitudeAccuracy":null,"heading":null,"latitude":"23.12004910","longitude":"113.30764968","speed":null,"timestamp":null,"point":{"lng":113.30764968,"lat":23.1200491},"address":{"city":"广州市","city_code":0,"district":"","province":"广东省","street":"","street_number":""}}
**ipCityInfo** | *Object* | 根据当前IP地址获取到的用户城市信息，包括城市名、百度cityCode、城市中心点经纬度信息 | {"center":{"lng":113.270793,"lat":23.135308},"level":12,"name":"广州市","code":257}
**ipCityCode** | *Number* | 根据当前IP地址获取到的用户城市代码（百度cityCode） | 257
**ipCity** | *Object* | 当前IP地址所在城市在YCS城市列表中对应的信息 | {"c":440100,"pc":440000,"n":"广州市","pn":"广东省","bc":257}
**customAddress** | *String* | 用以记录用户自行输入/校正的地址信息 | "金穗路30号"
**customCoord** | *Object* | 根据上述用户自行输入的地址进行重新校正后的经纬度坐标 | { "lng": 113.324634, "lat": 23.129296 }
**selectedCity** | *Object* | 城市列表中当前选中的城市信息，包括省名、市名、省行政编号、市行政编号、百度cityCode | {"c":110100,"pc":110000,"n":"北京市","pn":"北京市","bc":131}
**selectedCityCode** | *Number* | 用户选中的城市代码（百度CityCode） | 131