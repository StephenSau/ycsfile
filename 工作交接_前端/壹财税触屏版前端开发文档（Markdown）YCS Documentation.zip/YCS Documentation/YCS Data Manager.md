# YCS Data Manager #

通过引入 **window.YCS.UTIL.Data** 获得

## 1. 常用方法

### store 保存数据

> store( key, data, type )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**key** | *String* |  | 【必传】要保存的数据名称，将作为以后索引的唯一依据
**data** | *任意* |  | 要保存的具体数据，格式不限，通常为 Object, Number, String, Boolean
**type** | *String* | 'session' | 储存位置。默认值为`session`: 存入sessionStorage；`local`: 存入localStorage

### get 获取数据

> get( key, type )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**key** | *String* |  | 【必传】要获取的数据名称
**type** | *String* | 'session' | 储存位置。默认值为`session`: 从sessionStorage读取；`local`: 从localStorage读取

### remove 删除数据

> remove( key, type )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**key** | *String* |  | 【必传】要移除的数据名称
**type** | *String* | 'session' | 储存位置。默认值为`session`: 从sessionStorage移除；`local`: 从localStorage移除

## 2. 较少用的方法

### checkExpiry 检验数据是否过期

> checkExpiry( key, type, timeout )

使用上文的`store`方法储存数据时，API会自行记录该数据的最后更新时间戳，本方法则通过对比最后更新时间戳来判断数据是否在有效期内。

**又另：如果要查询用户定位及百度地图相关的数据，请调用 ==YCS Location== 中的`checkExisting`方法，更加便捷。**

参数 | 类型 | 默认值 | 说明
---|---|---|---
**key** | *String* |  | 【必传】要检验的数据名称
**type** | *String* | 'session' | 储存位置。默认值为`session`: 从sessionStorage读取；`local`: 从localStorage读取
**timeout** | *Number* |  | 数据保鲜时间（单位：ms），e.g. 传`10000`则表示认定该数据在储存后10秒后过期

### support 检测浏览器是否支持HTML5 Storage

> support()

通常会在应用层级通过modernizr进行检验，基本上不需要额外调用