# YCS Tool #

通过引入 **window.YCS.TOOL** 获得

## 常用方法

### getParams 获取URL参数

> getParams( seg )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**seg** | *String* |  | 【必传】任意参数名称

### listen 添加侦听

> listen( target, eventType, callback )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**target** | *Object* |  | 【必传】DOM对象
**eventType** | *String* |  | 【必传】侦听事件名称
**callback** | *Function* |  | 【必传】回调函数

### unlisten 移除侦听

> unListen( target, eventType, callback )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**target** | *Object* |  | 【必传】DOM对象
**eventType** | *String* |  | 【必传】侦听事件名称
**callback** | *Function* |  | 【必传】回调函数

### emitEvent 自定义事件

> emitEvent( target, eventType, eventData, delay )

参数 | 类型 | 默认值 | 说明
---|---|---|---
**target** | *Object* |  | 【必传】DOM对象
**eventType** | *String* |  | 【必传】发出的事件名称
**eventData** | *任意* |  | 事件包含的数据，可不传。格式不限，通常为 Object, Number, String, Boolean
**delay** | *Number* | 0 | 用于延迟发送事件（单位：ms），不填则马上发送。